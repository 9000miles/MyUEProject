// Fill out your copyright notice in the Description page of Project Settings.


#include "CommonToolBPFunctionLibrary.h"
//
//USaveGameManager* UCommonToolBPFunctionLibrary::GetSaveGameManager()
//{
//
//	return USaveGameManager::GetSaveGameManager();
//}
