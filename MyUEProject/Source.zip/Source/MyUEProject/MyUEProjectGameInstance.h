// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintPlatformLibrary.h"
#include "MyUEProjectGameInstance.generated.h"

/**
 *
 */
UCLASS()
class UMyUEProjectGameInstance : public UPlatformGameInstance
{
	GENERATED_BODY()

};