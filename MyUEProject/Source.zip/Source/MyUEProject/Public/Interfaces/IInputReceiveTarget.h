// Copyright 1998-2019 Epic Games, Inc. All Rights Reserved.

#pragma once

//#include "InputManager.h"
//#include "IInputReceiveTarget.generated.h"
////
/////** Interface for actors which can be selected */
//UINTERFACE(MinimalAPI)
//class UInputReceiveTarget : public UInterface
//{
//	GENERATED_UINTERFACE_BODY()
//};
//
//class IInputReceiveTarget
//{
//	GENERATED_IINTERFACE_BODY()
//public:
//	//UFUNCTION(BlueprintCallable, BlueprintImplementableEvent, Category = "Input Receive Interface")
//		//void ReceiveKey(TEnumAsByte<EInputKey::Type> Key, bool Pressed);
//
//	//UFUNCTION(BlueprintCallable, BlueprintImplementableEvent, Category = "Input Receive Interface")
//	UFUNCTION(BlueprintNativeEvent)
//			void ReceiveAxis(float MoveForwardAxis, float MoveRightAxis, float LookUpAxis, float LookRateAxis);
//
//	//UFUNCTION(BlueprintCallable, BlueprintImplementableEvent, Category = "Input Receive Interface")
//	//	void ReceiveDownKeys(TArray<TEnumAsByte<EInputKey::Type>>& Keys);
//};